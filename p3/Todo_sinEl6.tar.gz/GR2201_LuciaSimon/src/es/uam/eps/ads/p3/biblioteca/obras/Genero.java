package es.uam.eps.ads.p3.biblioteca.obras;

public enum Genero {
	DRAMA, COMEDIA, TEATRO, TERROR
}
